<template>
  <div id="app">
    <nav>
      <router-link to="/list">List</router-link> |
      <router-link to="/detail">Detail</router-link>
    </nav>
    <router-view/>
  </div>
</template>

<style>

</style>
